from django.urls import path
from . import views

app_name = 'messages'

urlpatterns = [
    path('', views.message_list, name='message_list'),
    path('send/', views.send_message, name='send_message'),
    path('send/<int:receiver_id>/', views.send_message, name='send_message_to_user'),
    path('send/<int:receiver_id>/<int:product_id>/', views.send_message, name='send_message_with_product'),
]