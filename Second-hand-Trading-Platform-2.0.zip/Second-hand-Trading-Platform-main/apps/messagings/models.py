from django.db import models
from apps.users.models import User  # 假设 User 模型在 users 应用中
from apps.listings.models import Product  # 假设 Product 模型在 listings 应用中

class Message(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="received_messages")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="messages", null=True, blank=True)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"Message from {self.sender} to {self.receiver}"