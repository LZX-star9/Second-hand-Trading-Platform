from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Message
from apps.users.models import User
from apps.listings.models import Product
from .forms import MessageForm

@login_required
def message_list(request):
    # 获取当前用户收到的消息和发送的消息
    received_messages = Message.objects.filter(receiver=request.user).order_by('-timestamp')
    sent_messages = Message.objects.filter(sender=request.user).order_by('-timestamp')
    return render(request, 'messages/message_list.html', {
        'received_messages': received_messages,
        'sent_messages': sent_messages,
    })

@login_required
def send_message(request, receiver_id=None, product_id=None):
    receiver = None
    product = None
    if receiver_id:
        receiver = get_object_or_404(User, id=receiver_id)
    if product_id:
        product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = receiver
            message.product = product
            message.save()
            return redirect('messages:message_list')
    else:
        form = MessageForm()
    return render(request, 'messages/send_message.html', {
        'form': form,
        'receiver': receiver,
        'product': product,
    })